document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault();  // Evita il comportamento predefinito del form (refresh della pagina)

  // Ottieni i valori del modulo
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Crea l'oggetto dati per il login
  const loginData = {
      email: email,
      password: password
  };

  // Invia la richiesta al server per il login
  fetch('http://127.0.0.1:5000/signin', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify(loginData)
  })
  .then(response => response.json())  // Ricevi la risposta JSON dal server
  .then(data => {
      if (data.message === "Login successful") {
          // Salva le informazioni dell'utente nella sessione del browser
          localStorage.setItem('user', JSON.stringify(data.user));

          // Reindirizza alla pagina del profilo
          window.location.href = 'profile.html';  // Reindirizza alla pagina profile.html
      } else {
          alert(data.error);  // Mostra errore se il login non è riuscito
      }
  })
  .catch(error => {
      console.error('Error:', error);
      alert('Errore nel login, per favore riprova.');
  });
});
