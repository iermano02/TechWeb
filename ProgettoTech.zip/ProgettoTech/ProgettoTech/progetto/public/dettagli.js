const apiKey = '181a29bd6ec4295c6e62e96dd6966352';
const baseUrl = 'https://api.themoviedb.org/3';

// Funzione per ottenere i dettagli del film dall'API
async function getMovieDetails(movieId) {
    const url = `${baseUrl}/movie/${movieId}?api_key=${apiKey}&language=en-US`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        
        document.getElementById('movieTitle').innerText = data.title;
        document.getElementById('movieOverview').innerText = data.overview;
        document.getElementById('moviePoster').src = `https://image.tmdb.org/t/p/w500${data.poster_path}`;
        // Aggiungi la logica per disabilitare la recensione se il film non è ancora uscito
        const releaseDate = new Date(data.release_date); // Ottieni la data di uscita del film
        const today = new Date(); // Ottieni la data odierna

        if (releaseDate > today) {
            // Se il film non è uscito, nascondi il form per la recensione
            document.getElementById('reviewText').style.display = 'none';
            document.getElementById('submitReview').style.display = 'none';
            // Usa il loginMessage per mostrare che il film non è ancora uscito
            const loginMessage = document.getElementById('loginMessage');
            loginMessage.textContent = "Questo film non è ancora uscito. Puoi scrivere una recensione dopo la sua uscita.";
            loginMessage.style.color = 'orange'; // Imposta il colore a arancione
            loginMessage.style.display = 'block'; // Mostra il messaggio
            document.getElementById('tastologin').style.display = 'none';
        } else {
            // Se il film è già uscito, mostra il form per la recensione
            const user = JSON.parse(localStorage.getItem('user'));
            if (user) {
                document.getElementById('reviewText').style.display = 'inline-block';
                document.getElementById('submitReview').style.display = 'inline-block';
            } else {
                document.getElementById('loginMessage').style.display = 'block';
                document.getElementById('tastologin').style.display = 'block';
            }
        }
    } catch (error) {
        console.error('Error fetching movie details:', error);
    }
}

// Funzione per ottenere l'ID del film dalla query string
function getMovieIdFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id');
}

// Funzione per caricare le recensioni dal server
function loadReviews(movieId) {
    const reviewsContainer = document.getElementById('reviewsContainer');
    reviewsContainer.innerHTML = '';  // Pulisce il contenitore delle recensioni prima di caricarle

    fetch(`http://127.0.0.1:5000/get_reviews?movieId=${movieId}`)
        .then(response => response.json())
        .then(data => {
            if (data.reviews && data.reviews.length > 0) {
                data.reviews.forEach(review => {
                    const reviewDiv = document.createElement('div');
                    reviewDiv.classList.add('review');
                    reviewDiv.innerHTML = `
                        <p><strong>${review.userEmail}</strong>:</p>
                        <p>${review.reviewText}</p>
                    `;
                    reviewsContainer.appendChild(reviewDiv);
                });
            } else {
                reviewsContainer.innerHTML = '<p>No reviews available for this movie.</p>';
            }
        })
        .catch(error => {
            console.error('Error fetching reviews:', error);
        });
}

// Funzione per inviare la recensione al server
document.getElementById('submitReview').addEventListener('click', function() {
    const reviewText = document.getElementById('reviewText').value;
    const movieId = getMovieIdFromUrl();

    if (!reviewText) {
        alert('Devi scrivere una recensione!');
        return;
    }

    const user = JSON.parse(localStorage.getItem('user')); // Ottieni le informazioni dell'utente dalla sessione

    if (!user) {
        alert('Devi essere loggato per scrivere una recensione.');
        return;
    }

    const reviewData = {
        movieId: movieId,
        userEmail: user.email,
        reviewText: reviewText
    };

    // Invia la recensione al server
    fetch('http://127.0.0.1:5000/submit_review', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(reviewData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(errorData => {
                throw new Error(errorData.error || 'Errore sconosciuto');
            });
        }
        return response.json();  // Se la risposta è OK, restituisci la risposta JSON
    })
    .then(data => {
        if (data.message === "Review submitted successfully") {
            alert('Recensione inviata!');
            loadReviews(movieId);  // Ricarica le recensioni dopo l'invio
        } else {
            alert('Errore durante l\'invio della recensione');
        }
    })
    .catch(error => {
        console.error('Error:', error);  // Mostra l'errore nella console
        alert('Errore nel processo di invio della recensione: ' + error.message);
    });
});

// Funzione per tornare alla pagina dei risultati di ricerca
document.getElementById('backToResults').addEventListener('click', () => {
    // Ottieni l'URL della pagina di provenienza
    const referrer = document.referrer;
  
    // Verifica da quale pagina è arrivato l'utente e reindirizza
    if (referrer.includes('index.html')) {
      window.location.href = 'index.html';
    } else if (referrer.includes('filminsala.html')) {
      window.location.href = 'filminsala.html';
    } else if (referrer.includes('filmpopolari.html')) {
      window.location.href = 'filmpopolari.html';
    } else if (referrer.includes('inarrivo.html')) {
        window.location.href = 'inarrivo.html';
      } else {
      // Reindirizza a una pagina predefinita se il referrer non è riconosciuto
      window.location.href = 'index.html';
    }
  });
  

// Carica i dettagli del film e le recensioni al caricamento della pagina
document.addEventListener('DOMContentLoaded', () => {
    const movieId = getMovieIdFromUrl();
    if (movieId) {
        getMovieDetails(movieId);
        loadReviews(movieId);  // Carica le recensioni al caricamento della pagina
    } else {
        alert('No movie ID found.');
    }
});

// Funzione per inviare il like al server
document.getElementById('likeButton').addEventListener('click', function() {
    const movieId = getMovieIdFromUrl();
    const user = JSON.parse(localStorage.getItem('user'));

    if (!user) {
        alert('Devi essere loggato per mettere like.');
        return;
    }

    const likeData = {
        movieId: movieId,
        userEmail: user.email
    };

    fetch('http://127.0.0.1:5000/like_movie', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(likeData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(errorData => {
                throw new Error(errorData.error || 'Errore sconosciuto');
            });
        }
        return response.json();
    })
    .then(data => {
        alert('Like aggiunto con successo!');
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Errore nel processo di like: ' + error.message);
    });
});