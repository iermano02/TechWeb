const apiKey = '181a29bd6ec4295c6e62e96dd6966352';
const baseUrl = 'https://api.themoviedb.org/3';
let currentMovieId = null; // Variabile per memorizzare l'ID del film selezionato

// Funzione per caricare i film in evidenza
async function loadFeaturedMovies() {
  const url = `${baseUrl}/trending/movie/week?api_key=${apiKey}&language=en-US&page=1`;
  try {
    const response = await fetch(url);
    const data = await response.json();

    // Mostra il titolo "On Trend"
    document.querySelector('.trending-title').style.display = 'block';

    if (data.results.length === 0) {
      document.getElementById('results').innerHTML = '<p>No movies found.</p>';
    } else {
      // Mostra solo i primi 14 film
      displayMovies(data.results.slice(0, 14));
    }
  } catch (error) {
    console.error('Error fetching popular movies:', error);
    document.getElementById('results').innerHTML = '<p>Something went wrong. Please try again later.</p>';
  }
}


// Funzione per visualizzare i film
function displayMovies(movies) {
  const resultsContainer = document.getElementById('results');
  resultsContainer.innerHTML = ''; // Pulisce i risultati precedenti

  if (movies.length === 0) {
    resultsContainer.innerHTML = '<p>No movies available.</p>';
    return;
  }

  movies.forEach(movie => {
    const movieCard = document.createElement('div');
    movieCard.classList.add('movie-card');
    movieCard.dataset.movieId = movie.id;

    const moviePoster = movie.poster_path
      ? `<img src="https://image.tmdb.org/t/p/w500${movie.poster_path}" alt="${movie.title}">`
      : `<div style="height: 200px; background: #ddd; border-radius: 8px;">No Image</div>`;

    movieCard.innerHTML = `
      ${moviePoster}
      <h3>${movie.title}</h3>
      <p>Rating: ${movie.vote_average || 'N/A'}</p>
      <button class="view-details-button">View Details</button>
    `;

    const viewDetailsButton = movieCard.querySelector('.view-details-button');
    viewDetailsButton.addEventListener('click', () => {
      // Reindirizza alla pagina dei dettagli passando l'ID del film come parametro nell'URL
      window.location.href = `dettagli.html?id=${movie.id}`;
    });

    resultsContainer.appendChild(movieCard);
  });
}

// Funzione per cercare film
async function searchMovies(query) {
  const url = `${baseUrl}/search/movie?api_key=${apiKey}&query=${encodeURIComponent(query)}&language=en-US&page=1`;
  try {
    const response = await fetch(url);
    const data = await response.json();

    // Nascondi il titolo "On Trend"
    document.querySelector('.trending-title').style.display = 'none';

    if (data.results.length === 0) {
      document.getElementById('results').innerHTML = '<p>No movies found matching your search.</p>';
    } else {
      // Mostra i risultati della ricerca
      displayMovies(data.results);
    }
  } catch (error) {
    console.error('Error searching movies:', error);
    document.getElementById('results').innerHTML = '<p>Something went wrong. Please try again later.</p>';
  }
}


// Gestore evento per il tasto di ricerca
document.getElementById('searchButton').addEventListener('click', () => {
  const query = document.getElementById('searchInput').value.trim();
  if (query) {
    searchMovies(query);
  } else {
    alert('Please enter a movie name to search.');
  }
});

window.addEventListener('load', loadFeaturedMovies);
