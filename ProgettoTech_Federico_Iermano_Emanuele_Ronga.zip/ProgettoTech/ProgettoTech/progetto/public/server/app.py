from flask import Flask, request, jsonify, session
from pymongo import MongoClient
from flask_cors import CORS
import bcrypt

app = Flask(__name__)
app.secret_key = 'your_secret_key'  
CORS(app)

# Connessione a MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["yourdbname"]  
users = db["users"]  


# Rotta per la registrazione (signup)
@app.route('/signup', methods=['GET'])
def signup():
    return "Signup page", 200


# Rotta per gestire la registrazione
@app.route('/signup', methods=['POST'])
def handle_signup():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    if not username or not email or not password:
        return jsonify({"error": "Username, email, and password are required"}), 400

    # Verifica se l'utente o l'email esiste già
    if users.find_one({"username": username}):
        return jsonify({"error": "Username already exists"}), 409

    if users.find_one({"email": email}):
        return jsonify({"error": "Email already in use"}), 409

    # Hash della password
    hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    # Salva l'utente nel database
    users.insert_one({
        "username": username,
        "email": email,
        "password": hashed_pw,
        "__v": 0  # Versione iniziale
    })
    return jsonify({"message": "User registered successfully"}), 201


# Rotta per il login
@app.route('/signin', methods=['POST'])
def signin():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    # Verifica che l'utente esista nel database
    user = users.find_one({"email": email})

    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    if not bcrypt.checkpw(password.encode('utf-8'), user['password']):
        return jsonify({"error": "Invalid credentials"}), 401

    # Salva le informazioni dell'utente nella sessione
    session['user'] = {
        'username': user['username'],
        'email': user['email']
    }

    return jsonify({
        "message": "Login successful",
        "user": {
            "username": user['username'],
            "email": user['email']
        }
    }), 200


# Rotta per inviare una recensione
@app.route('/submit_review', methods=['POST'])
def submit_review():
    # Ottieni i dati dalla richiesta JSON
    data = request.get_json()
    
    # Estrai i dati dalla richiesta
    movie_id = data.get('movieId')
    user_email = data.get('userEmail')
    review_text = data.get('reviewText')

    # Verifica che tutti i campi siano presenti
    if not movie_id or not user_email or not review_text:
        return jsonify({"error": "Movie ID, user email, and review text are required"}), 400

    reviews = db["reviews"]
    reviews.insert_one({
        "movieId": movie_id,
        "userEmail": user_email,
        "reviewText": review_text
    })

    return jsonify({"message": "Review submitted successfully"}), 201


@app.route('/get_reviews', methods=['GET'])
def get_reviews():
    movie_id = request.args.get('movieId')  

    if not movie_id:
        return jsonify({"error": "Movie ID is required"}), 400

    # Recupera le recensioni per il film specificato
    reviews = db["reviews"]
    movie_reviews = reviews.find({"movieId": movie_id})

    reviews_list = []
    for review in movie_reviews:
        reviews_list.append({
            "userEmail": review['userEmail'],
            "reviewText": review['reviewText']
        })

    return jsonify({"reviews": reviews_list}), 200






# Rotta per il logout
@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user', None)
    return jsonify({"message": "Logout successful"}), 200


    # Rotta per mettere like a un film
@app.route('/like_movie', methods=['POST'])
def like_movie():
    data = request.get_json()
    movie_id = data.get('movieId')
    user_email = data.get('userEmail')

    if not movie_id or not user_email:
        return jsonify({"error": "Movie ID and user email are required"}), 400

    # Verifica se il like esiste già
    likes = db["likes"]
    if likes.find_one({"movieId": movie_id, "userEmail": user_email}):
        return jsonify({"error": "You have already liked this movie"}), 409

    # Inserisci il like nel database
    likes.insert_one({
        "movieId": movie_id,
        "userEmail": user_email
    })

    return jsonify({"message": "Like added successfully"}), 201


# Rotta per ottenere i film piaciuti dall'utente
@app.route('/get_liked_movies', methods=['GET'])
def get_liked_movies():
    user_email = request.args.get('userEmail')

    if not user_email:
        return jsonify({"error": "User email is required"}), 400

    likes = db["likes"]
    liked_movies = likes.find({"userEmail": user_email})

    liked_movie_ids = [like['movieId'] for like in liked_movies]

    return jsonify({"likedMovies": liked_movie_ids}), 200


# Rotta per rimuovere il like da un film
@app.route('/remove_like', methods=['POST'])
def remove_like():
    data = request.get_json()
    movie_id = data.get('movieId')
    user_email = data.get('userEmail')

    if not movie_id or not user_email:
        return jsonify({"error": "Movie ID and user email are required"}), 400

    # Rimuovi il like dal database
    likes = db["likes"]
    like = likes.find_one({"movieId": movie_id, "userEmail": user_email})

    if not like:
        return jsonify({"error": "Like not found"}), 404

    # Rimuovi il like
    likes.delete_one({"movieId": movie_id, "userEmail": user_email})

    return jsonify({"message": "Like removed successfully"}), 200


import requests

@app.route('/get_user_reviews', methods=['GET'])
def get_user_reviews():
    user_email = request.args.get('userEmail')  

    if not user_email:
        return jsonify({"error": "User email is required"}), 400

    # Recupera le recensioni per l'utente specificato
    reviews = db["reviews"]
    user_reviews = reviews.find({"userEmail": user_email})

    api_key = '181a29bd6ec4295c6e62e96dd6966352'  
    reviews_list = []

    for review in user_reviews:
        movie_id = review['movieId']
        # Chiamata all'API di TMDB per ottenere il titolo del film
        tmdb_response = requests.get(f'https://api.themoviedb.org/3/movie/{movie_id}?api_key={api_key}&language=en-US')
        if tmdb_response.status_code == 200:
            movie_data = tmdb_response.json()
            movie_title = movie_data.get('title', 'Unknown Title')
        else:
            movie_title = 'Unknown Title'

        reviews_list.append({
            "movieTitle": movie_title,
            "reviewText": review['reviewText']
        })

    return jsonify({"reviews": reviews_list}), 200


# Rotta per cercare un utente per nome o email
@app.route('/search_user', methods=['GET'])
def search_user():
    query = request.args.get('query')

    if not query:
        return jsonify({"error": "Search query is required"}), 400

    user = users.find_one({
        "$or": [
            {"username": {"$regex": query, "$options": "i"}},
            {"email": {"$regex": query, "$options": "i"}}
        ]
    })

    if not user:
        return jsonify({"user": None}), 200  # Se non trovato, restituisci un oggetto vuoto

    # Ottieni il numero di recensioni e likes per l'utente
    reviews_count = db["reviews"].count_documents({"userEmail": user['email']})
    likes_count = db["likes"].count_documents({"userEmail": user['email']})

    # Recupera i film piaciuti dall'utente
    liked_movies = db["likes"].find({"userEmail": user['email']})
    liked_movie_ids = [like['movieId'] for like in liked_movies]

    # Recupera le recensioni dell'utente
    user_reviews = db["reviews"].find({"userEmail": user['email']})
    reviews_list = []
    for review in user_reviews:
        tmdb_response = requests.get(f'https://api.themoviedb.org/3/movie/{review["movieId"]}?api_key=181a29bd6ec4295c6e62e96dd6966352&language=en-US')
        movie_title = 'Unknown Title'  # Default in caso di errore nell'API
        if tmdb_response.status_code == 200:
            movie_title = tmdb_response.json().get('title', 'Unknown Title')
        
        reviews_list.append({
            "movieTitle": movie_title,
            "reviewText": review['reviewText']
        })

    # Recupera il colore dell'avatar dall'utente, se presente
    avatar_color = user.get('avatarColor', '#007bff')  

    # Crea un oggetto con i dettagli dell'utente, recensioni, film piaciuti e colore dell'avatar
    user_profile = {
        "username": user['username'],
        "email": user['email'],
        "reviewsCount": reviews_count,
        "likesCount": likes_count,
        "likedMovies": liked_movie_ids,
        "reviews": reviews_list,
        "avatarColor": avatar_color  
    }

    return jsonify({"user": user_profile}), 200

#endpoint per aggiornare il colore dell'avatar
@app.route('/update_avatar_color', methods=['POST'])
def update_avatar_color():
    data = request.get_json()
    user_email = data.get('userEmail')
    avatar_color = data.get('avatarColor')

    if not user_email or not avatar_color:
        return jsonify({"error": "Email and avatar color are required"}), 400

    user = users.find_one({"email": user_email})
    if not user:
        return jsonify({"error": "User not found"}), 404

    users.update_one(
        {"email": user_email},
        {"$set": {"avatarColor": avatar_color}}
    )

    return jsonify({"message": "Avatar color updated successfully"}), 200

#endpoint per ritornare il colore dell'avatar dell'utente
@app.route('/get_avatar_color', methods=['GET'])
def get_avatar_color():
    user_email = request.args.get('userEmail')

    if not user_email:
        return jsonify({"error": "User email is required"}), 400

    user = users.find_one({"email": user_email})
    if not user:
        return jsonify({"error": "User not found"}), 404

    # Restituisce il colore dell'avatar, se presente
    return jsonify({"avatarColor": user.get("avatarColor", "#007bff")}), 200


if __name__ == '__main__':
    app.run(debug=True)