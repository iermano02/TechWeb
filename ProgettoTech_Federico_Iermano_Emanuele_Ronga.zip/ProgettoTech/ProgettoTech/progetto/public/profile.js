const apiKey = '181a29bd6ec4295c6e62e96dd6966352';  // API key TMDB
const baseUrl = 'https://api.themoviedb.org/3';

// Funzione per caricare i film piaciuti dell'utente
function loadLikedMovies() {
    const user = JSON.parse(localStorage.getItem('user'));  // Recupera le informazioni dell'utente dalla sessione

    if (!user) {
        return;
    }

    fetch(`http://127.0.0.1:5000/get_liked_movies?userEmail=${user.email}`)
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('likedMoviesContainer');
            container.innerHTML = '';  // Svuota il contenitore prima di caricare i film

            if (data.likedMovies && data.likedMovies.length > 0) {
                data.likedMovies.forEach(movieId => {
                    fetchMovieDetails(movieId, container);
                });
            } else {
                container.innerHTML = '<p>No liked movies found.</p>';
            }
        })
        .catch(error => {
            console.error('Error fetching liked movies:', error);
            document.getElementById('likedMoviesContainer').innerHTML = '<p>Error loading liked movies.</p>';
        });
}

function fetchMovieDetails(movieId, container) {
    const url = `${baseUrl}/movie/${movieId}?api_key=${apiKey}&language=en-US`;
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            const movieCard = document.createElement('div');
            movieCard.classList.add('liked-movie-card');

            // Crea la card con immagine, titolo e ID del film
            movieCard.innerHTML = `
                <img src="https://image.tmdb.org/t/p/w500${data.poster_path}" alt="${data.title}">
                <p class="movie-title">${data.title}</p>
                <button class="remove-like-btn" data-movie-id="${movieId}">Remove Like</button>  <!-- Aggiungi il pulsante per rimuovere il like -->
            `;

            // Aggiungi l'evento per il pulsante "Remove Like"
            movieCard.querySelector('.remove-like-btn').addEventListener('click', () => {
                removeLike(movieId, movieCard);
            });

            container.appendChild(movieCard);  // Aggiungi la card al contenitore
        })
        .catch(error => {
            console.error(`Error fetching details for movie ID ${movieId}:`, error);
            const errorDiv = document.createElement('div');
            errorDiv.classList.add('liked-movie-card');
            errorDiv.innerHTML = `<p>Error loading movie details (ID: ${movieId})</p>`;
            container.appendChild(errorDiv);
        });
}

// Funzione per rimuovere un like
function removeLike(movieId, movieCard) {
    const user = JSON.parse(localStorage.getItem('user'));  // Recupera le informazioni dell'utente dalla sessione

    if (!user) {
        alert('Devi essere loggato per rimuovere un like.');
        return;
    }

    const likeData = {
        movieId: movieId,
        userEmail: user.email
    };

    // Invia una richiesta al server per rimuovere il like
    fetch('http://127.0.0.1:5000/remove_like', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(likeData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(errorData => {
                throw new Error(errorData.error || 'Errore sconosciuto');
            });
        }
        return response.json();
    })
    .then(data => {
        alert('Like rimosso con successo!');
        movieCard.remove();  // Rimuovi la card del film dalla pagina
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Errore nel processo di rimozione del like: ' + error.message);
    });
}
// Carica i film piaciuti quando la pagina è completamente caricata
document.addEventListener('DOMContentLoaded', loadLikedMovies);

// Carica i dettagli del film e le recensioni al caricamento della pagina
document.addEventListener('DOMContentLoaded', () => {
    const movieId = getMovieIdFromUrl();
    if (movieId) {
        getMovieDetails(movieId);
        loadReviews(movieId);  
    } else {
        alert('No movie ID found.');
    }
});

// Funzione per caricare le recensioni effettuate dall'utente
function loadUserReviews() {
    const user = JSON.parse(localStorage.getItem('user'));  

    if (!user) {
        return;
    }

    fetch(`http://127.0.0.1:5000/get_user_reviews?userEmail=${user.email}`)
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('userReviewsContainer');
            container.innerHTML = '';  

            if (data.reviews && data.reviews.length > 0) {
                data.reviews.forEach(review => {
                    const reviewDiv = document.createElement('div');
                    reviewDiv.classList.add('user-review');
                    reviewDiv.innerHTML = `
                        <p><strong>Film: ${review.movieTitle}</strong></p>
                        <p><strong>Review:${review.reviewText}</strong></p>
                    `;
                    container.appendChild(reviewDiv);
                });
            } else {
                container.innerHTML = '<p>No reviews found.</p>';
            }
        })
        .catch(error => {
            console.error('Error fetching user reviews:', error);
            document.getElementById('userReviewsContainer').innerHTML = '<p>Error loading reviews.</p>';
        });
}

// Carica i film piaciuti e le recensioni dell'utente quando la pagina è completamente caricata
document.addEventListener('DOMContentLoaded', () => {
    loadUserReviews();
});

function searchUser() {
    const searchQuery = document.getElementById('searchInput').value.trim();
    
    if (!searchQuery) {
        alert('Inserisci un nome o un email per la ricerca.');
        return;
    }

    // Invia una richiesta al server per cercare l'utente
    fetch(`http://127.0.0.1:5000/search_user?query=${searchQuery}`)
        .then(response => response.json())
        .then(data => {
            if (data.user) {
                // Redirige alla pagina del profilo utente
                window.location.href = `userProfilePage.html?email=${data.user.email}`;
            } else {
                alert('Nessun utente trovato.');
            }
        })
        .catch(error => {
            console.error('Error fetching user profile:', error);
            alert('Errore nel caricamento del profilo utente.');
        });
}



// Aggiungi l'evento per il tasto di ricerca
document.getElementById('searchButton').addEventListener('click', searchUser);


// Funzione per salvare il colore dell'avatar per l'utente specifico
function saveAvatarColor(color) {
    const user = JSON.parse(localStorage.getItem('user'));  

    if (!user) {
        alert('Devi essere loggato per salvare il colore dell\'avatar.');
        return;
    }

    // Salva il colore sul server
    fetch('http://127.0.0.1:5000/update_avatar_color', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userEmail: user.email,
            avatarColor: color
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Avatar color updated successfully') {
            // Aggiorna l'avatar nell'elemento HTML
            const avatarElement = document.getElementById('user-avatar');
            avatarElement.style.backgroundColor = color;
        } else {
            alert('Errore nel salvataggio del colore dell\'avatar');
        }
    })
    .catch(error => {
        console.error('Errore durante il salvataggio del colore:', error);
        alert('Errore nel salvataggio del colore dell\'avatar');
    });
}

// Funzione per caricare il colore dell'avatar dell'utente
function loadAvatarColor() {
    const user = JSON.parse(localStorage.getItem('user'));  

    if (!user) {
        alert('Devi essere loggato per caricare il colore dell\'avatar.');
        return;
    }

    // Invia una richiesta per ottenere il colore dell'avatar dal server
    fetch(`http://127.0.0.1:5000/get_avatar_color?userEmail=${user.email}`)
        .then(response => response.json())
        .then(data => {
            const avatarElement = document.getElementById('user-avatar');
            const savedColor = data.avatarColor;

            if (savedColor) {
                // Se un colore è stato trovato, applicalo all'avatar
                avatarElement.style.backgroundColor = savedColor;
                document.getElementById('colorPicker').value = savedColor; // Imposta il valore del color picker
            } else {
                // Se non esiste un colore salvato, imposta il colore predefinito
                avatarElement.style.backgroundColor = '#007bff'; // Colore predefinito
            }
        })
        .catch(error => {
            console.error('Errore nel caricamento del colore dell\'avatar:', error);
            alert('Errore nel caricamento del colore dell\'avatar');
        });
}

// Aggiorna il colore dell'avatar quando l'utente seleziona un colore
document.getElementById('colorPicker').addEventListener('input', (event) => {
    const selectedColor = event.target.value;
    const avatarElement = document.getElementById('user-avatar');

    avatarElement.style.backgroundColor = selectedColor;

    avatarElement.style.transition = 'background-color 0.3s ease';

    saveAvatarColor(selectedColor);
});

document.addEventListener('DOMContentLoaded', loadAvatarColor);


